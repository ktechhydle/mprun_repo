# Folder: `V-C STOR`

> [!IMPORTANT]
> This is where MPRUN stores the Vectorize tool outputs. ***IF this directory is DELETED, the software WILL NOT function properly!!***
