# File: `Course Element`

> [!IMPORTANT]
> This is where all Course Element files are stored. ***IF any of these files are modified or changed, the software WILL NOT function properly!!***
